# 📄 init_db.py (KOREKSI DENGAN LOOP INSERSI OTOMATIS)

import sqlite3

# --- 1. DEKLARASI DATA PRODUK ---

products_data = []

# --- 2. KONEKSI DAN INISIALISASI ---

conn = sqlite3.connect("database.db")
c = conn.cursor()

# HAPUS TABEL LAMA (agar perubahan skema 'category' diterapkan)
c.execute("DROP TABLE IF EXISTS products")

# BUAT TABEL BARU (dengan kolom 'category' yang sudah benar)
c.execute("""
CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    price INTEGER,
    category TEXT, 
    image TEXT
)
""")

# --- 3. INSERSI OTOMATIS MENGGUNAKAN LOOP ---
# Menggunakan 'executemany' lebih efisien daripada loop c.execute
sql_insert = "INSERT INTO products (name, price, category, image) VALUES (?, ?, ?, ?)"
c.executemany(sql_insert, products_data)

conn.commit()
conn.close()

print("Database 'database.db' berhasil diinisialisasi dengan", len(products_data), "produk.")